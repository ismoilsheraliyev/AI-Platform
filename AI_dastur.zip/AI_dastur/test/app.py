import os
import io
import zipfile
import tempfile
import shutil
from flask import Flask, render_template, request, send_file, jsonify, Response, stream_with_context
from PIL import Image
import PyPDF2
from werkzeug.utils import secure_filename
import logging
from fpdf import FPDF
import gc
import time

app = Flask(__name__)
# Cheksiz fayl hajmi uchun limitni olib tashlaymiz
app.config['MAX_CONTENT_LENGTH'] = None  # Cheksiz fayl hajmi
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['COMPRESSED_FOLDER'] = 'compressed'
app.config['ALLOWED_EXTENSIONS'] = {
    'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'tiff',  # Rasmlar
    'pdf',  # PDF fayllari
    'txt', 'docx', 'doc', 'rtf', 'md',  # Matn fayllari
    'zip', 'rar', '7z', 'tar', 'gz',  # Arxiv fayllari
    'mp3', 'wav', 'ogg',  # Audio fayllari
    'mp4', 'avi', 'mov', 'mkv',  # Video fayllari
    'ppt', 'pptx', 'xls', 'xlsx', 'csv'  # Office fayllari
}

# Papkalarni yaratish
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['COMPRESSED_FOLDER'], exist_ok=True)

# Logging sozlamalari
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(levelname)s - %(message)s',
                   handlers=[
                       logging.FileHandler('file_compressor.log'),
                       logging.StreamHandler()
                   ])

def allowed_file(filename):
    if '.' not in filename:
        return False
    ext = filename.rsplit('.', 1)[1].lower()
    return ext in app.config['ALLOWED_EXTENSIONS']

def get_file_size_mb(file_path):
    """Fayl hajmini MB da qaytarish"""
    return os.path.getsize(file_path) / (1024 * 1024)

def compress_image_streaming(file_stream, filename, quality=20):
    """Rasm fayllarini streaming orqali kichraytirish"""
    try:
        # Streaming orqali rasmni ochish
        img = Image.open(file_stream)
        
        # Formatni optimallashtirish
        if img.mode in ('RGBA', 'LA', 'P'):
            if img.mode == 'P':
                img = img.convert('RGBA')
            background = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'RGBA':
                background.paste(img, mask=img.split()[-1])
            else:
                background.paste(img, mask=img.getchannel('A'))
            img = background
        elif img.mode != 'RGB':
            img = img.convert('RGB')
        
        # O'lchamni optimallashtirish (agar katta bo'lsa)
        max_size = (3840, 2160)  # 4K gacha ruxsat beramiz
        img.thumbnail(max_size, Image.Resampling.LANCZOS)
        
        # Faylni memoryda saqlash
        output = io.BytesIO()
        
        # Fayl formatiga qarab saqlash
        if filename.lower().endswith(('.jpg', '.jpeg')):
            img.save(output, 'JPEG', optimize=True, quality=quality, progressive=True)
            content_type = 'image/jpeg'
            ext = 'jpg'
        elif filename.lower().endswith('.png'):
            img.save(output, 'PNG', optimize=True, compress_level=9)
            content_type = 'image/png'
            ext = 'png'
        elif filename.lower().endswith('.webp'):
            img.save(output, 'WEBP', quality=quality, method=6)
            content_type = 'image/webp'
            ext = 'webp'
        else:
            img.save(output, 'JPEG', optimize=True, quality=quality)
            content_type = 'image/jpeg'
            ext = 'jpg'
        
        output.seek(0)
        img.close()
        
        return output, content_type, ext
        
    except Exception as e:
        logging.error(f"Rasmni kichraytirishda xatolik: {str(e)}")
        return None, None, None

def compress_pdf_streaming(file_stream):
    """PDF fayllarini streaming orqali kichraytirish"""
    try:
        # PDF ni o'qish
        reader = PyPDF2.PdfReader(file_stream)
        writer = PyPDF2.PdfWriter()
        
        # Barcha sahifalarni o'qish
        for page in reader.pages:
            writer.add_page(page)
        
        # Metadata optimallashtirish
        if reader.metadata:
            writer.add_metadata(reader.metadata)
        
        # Memoryda saqlash
        output = io.BytesIO()
        writer.write(output)
        output.seek(0)
        
        return output, 'application/pdf', 'pdf'
        
    except Exception as e:
        logging.error(f"PDF ni kichraytirishda xatolik: {str(e)}")
        return None, None, None

def compress_text_streaming(file_stream, filename):
    """Matn fayllarini streaming orqali kichraytirish"""
    try:
        # Matnni o'qish
        content = file_stream.read().decode('utf-8', errors='ignore')
        
        # Optimallashtirish
        lines = content.split('\n')
        compressed_lines = []
        
        for line in lines:
            stripped = line.strip()
            if stripped:  # Faqat bo'sh bo'lmagan qatorlarni saqlash
                # Qo'shimcha optimallashtirish: ortiqcha bo'sh joylarni olib tashlash
                words = stripped.split()
                optimized_line = ' '.join(words)
                compressed_lines.append(optimized_line)
        
        compressed_content = '\n'.join(compressed_lines)
        
        # Memoryda saqlash
        output = io.BytesIO()
        output.write(compressed_content.encode('utf-8'))
        output.seek(0)
        
        # Content type ni aniqlash
        if filename.lower().endswith('.txt'):
            content_type = 'text/plain'
            ext = 'txt'
        elif filename.lower().endswith(('.doc', '.docx')):
            content_type = 'application/msword'
            ext = 'docx'
        elif filename.lower().endswith('.md'):
            content_type = 'text/markdown'
            ext = 'md'
        else:
            content_type = 'text/plain'
            ext = 'txt'
        
        return output, content_type, ext
        
    except Exception as e:
        logging.error(f"Matn faylini kichraytirishda xatolik: {str(e)}")
        return None, None, None

def compress_zip_streaming(file_stream, filename):
    """ZIP fayllarini streaming orqali optimallashtirish"""
    try:
        # Vaqtincha papka yaratish
        with tempfile.TemporaryDirectory() as temp_dir:
            # ZIP faylni ochish
            with zipfile.ZipFile(file_stream, 'r') as zip_ref:
                # Barcha fayllarni ro'yxatini olish
                file_list = zip_ref.namelist()
                
                # Yangi optimallashtirilgan arxiv yaratish
                output = io.BytesIO()
                with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as new_zip:
                    for file_name in file_list:
                        # Fayl ma'lumotlarini o'qish
                        with zip_ref.open(file_name) as file:
                            file_data = file.read()
                            
                            # Fayl turiga qarab optimallashtirish
                            if file_name.lower().endswith(('.jpg', '.jpeg', '.png', '.gif')):
                                # Rasm fayllarini optimallashtirish
                                try:
                                    img = Image.open(io.BytesIO(file_data))
                                    if img.mode in ('RGBA', 'LA', 'P'):
                                        if img.mode == 'P':
                                            img = img.convert('RGBA')
                                        background = Image.new('RGB', img.size, (255, 255, 255))
                                        if img.mode == 'RGBA':
                                            background.paste(img, mask=img.split()[-1])
                                        else:
                                            background.paste(img, mask=img.getchannel('A'))
                                        img = background
                                    elif img.mode != 'RGB':
                                        img = img.convert('RGB')
                                    
                                    img_byte_arr = io.BytesIO()
                                    if file_name.lower().endswith(('.jpg', '.jpeg')):
                                        img.save(img_byte_arr, 'JPEG', optimize=True, quality=50)
                                    elif file_name.lower().endswith('.png'):
                                        img.save(img_byte_arr, 'PNG', optimize=True, compress_level=9)
                                    else:
                                        img.save(img_byte_arr, 'JPEG', optimize=True, quality=50)
                                    
                                    img_byte_arr.seek(0)
                                    new_zip.writestr(file_name, img_byte_arr.read())
                                    img.close()
                                    continue
                                except:
                                    # Rasm optimallashtirish ishlamasa, oddiy saqlash
                                    pass
                            
                            # Boshqa fayllarni oddiy saqlash
                            new_zip.writestr(file_name, file_data)
            
            output.seek(0)
            return output, 'application/zip', 'zip'
            
    except Exception as e:
        logging.error(f"ZIP faylni kichraytirishda xatolik: {str(e)}")
        return None, None, None

def compress_generic_streaming(file_stream, filename):
    """Boshqa fayl turlari uchun umumiy kichraytirish"""
    try:
        # Fayl ma'lumotlarini o'qish
        original_data = file_stream.read()
        
        # Oddiy fayllar uchun hech qanday kichraytirish
        # Faqat turini aniqlash
        ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else 'bin'
        
        # Content type lar
        content_types = {
            'mp3': 'audio/mpeg',
            'wav': 'audio/wav',
            'ogg': 'audio/ogg',
            'mp4': 'video/mp4',
            'avi': 'video/x-msvideo',
            'mov': 'video/quicktime',
            'mkv': 'video/x-matroska',
            'ppt': 'application/vnd.ms-powerpoint',
            'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'xls': 'application/vnd.ms-excel',
            'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'csv': 'text/csv',
            'rar': 'application/vnd.rar',
            '7z': 'application/x-7z-compressed',
            'tar': 'application/x-tar',
            'gz': 'application/gzip'
        }
        
        content_type = content_types.get(ext, 'application/octet-stream')
        
        # Hech qanday o'zgartirishsiz qaytarish
        output = io.BytesIO(original_data)
        output.seek(0)
        
        return output, content_type, ext
        
    except Exception as e:
        logging.error(f"Faylni kichraytirishda xatolik: {str(e)}")
        return None, None, None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    """Faylni streaming orqali qabul qilish va kichraytirish"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Fayl tanlanmagan'}), 400
        
        file = request.files['file']
        compression_level = request.form.get('compression_level', 'medium')
        
        if file.filename == '':
            return jsonify({'error': 'Fayl tanlanmagan'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Ruxsat etilmagan fayl formati'}), 400
        
        # Sifat darajasini aniqlash
        quality_map = {
            'low': 15,
            'medium': 40,
            'high': 70,
            'extreme': 5
        }
        quality = quality_map.get(compression_level, 40)
        
        filename = secure_filename(file.filename)
        
        # Fayl hajmini o'lchash
        file.seek(0, 2)  # Oxiriga o'tish
        file_size = file.tell()
        file.seek(0)  # Boshiga qaytish
        
        logging.info(f"Fayl yuklandi: {filename}, hajmi: {file_size / (1024*1024):.2f} MB")
        
        # Fayl formatiga qarab kichraytirish
        file_ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
        
        if file_ext in ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'tiff']:
            compressed_data, content_type, new_ext = compress_image_streaming(file, filename, quality)
        elif file_ext == 'pdf':
            compressed_data, content_type, new_ext = compress_pdf_streaming(file)
        elif file_ext in ['txt', 'docx', 'doc', 'rtf', 'md']:
            compressed_data, content_type, new_ext = compress_text_streaming(file, filename)
        elif file_ext == 'zip':
            compressed_data, content_type, new_ext = compress_zip_streaming(file, filename)
        else:
            compressed_data, content_type, new_ext = compress_generic_streaming(file, filename)
        
        if compressed_data is None:
            return jsonify({'error': 'Faylni kichraytirishda xatolik yuz berdi'}), 500
        
        # Kichraytirilgan hajmni hisoblash
        compressed_size = compressed_data.tell()
        compression_rate = ((file_size - compressed_size) / file_size * 100) if file_size > 0 else 0
        
        logging.info(f"Fayl kichraytirildi: {filename}, "
                    f"boshlang'ich: {file_size / (1024*1024):.2f} MB, "
                    f"kichraytirilgan: {compressed_size / (1024*1024):.2f} MB, "
                    f"foiz: {compression_rate:.1f}%")
        
        # Memoryni tozalash
        gc.collect()
        
        return jsonify({
            'success': True,
            'original_filename': filename,
            'compressed_filename': f"compressed_{filename}",
            'original_size': file_size,
            'compressed_size': compressed_size,
            'compression_rate': round(compression_rate, 2),
            'saved_bytes': file_size - compressed_size,
            'content_type': content_type,
            'file_ext': new_ext
        })
        
    except Exception as e:
        logging.error(f"Fayl yuklashda xatolik: {str(e)}")
        return jsonify({'error': f'Server xatosi: {str(e)}'}), 500

@app.route('/download', methods=['POST'])
def download_file():
    """Kichraytirilgan faylni yuklab olish"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Ma\'lumotlar yetarli emas'}), 400
        
        original_filename = data.get('original_filename')
        compression_rate = data.get('compression_rate', 0)
        
        if not original_filename:
            return jsonify({'error': 'Fayl nomi berilmagan'}), 400
        
        # Faylni streaming orqali qayta ishlash va yuborish
        @stream_with_context
        def generate():
            # Memoryni tozalash
            gc.collect()
            
            # Bu yerda fayl streaming orqali qayta yuklanadi va kichraytiriladi
            # Ammo real loyihada bu ma'lumotlar sessiyada saqlanishi kerak
            # Hozircha demo uchun faqat xabar qaytaramiz
            yield f"Fayl: {original_filename} - {compression_rate}% kichraytirildi".encode('utf-8')
        
        return Response(generate(), mimetype='text/plain')
        
    except Exception as e:
        logging.error(f"Yuklab olishda xatolik: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/stream_compress', methods=['POST'])
def stream_compress():
    """Streaming orqali faylni kichraytirish va yuklab olish"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Fayl tanlanmagan'}), 400
        
        file = request.files['file']
        compression_level = request.form.get('compression_level', 'medium')
        
        if file.filename == '':
            return jsonify({'error': 'Fayl tanlanmagan'}), 400
        
        filename = secure_filename(file.filename)
        
        # Sifat darajasini aniqlash
        quality_map = {
            'low': 15,
            'medium': 40,
            'high': 70,
            'extreme': 5
        }
        quality = quality_map.get(compression_level, 40)
        
        # Fayl formatini aniqlash
        file_ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
        
        # Faylni kichraytirish
        if file_ext in ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'tiff']:
            compressed_data, content_type, new_ext = compress_image_streaming(file, filename, quality)
        elif file_ext == 'pdf':
            compressed_data, content_type, new_ext = compress_pdf_streaming(file)
        elif file_ext in ['txt', 'docx', 'doc', 'rtf', 'md']:
            compressed_data, content_type, new_ext = compress_text_streaming(file, filename)
        elif file_ext == 'zip':
            compressed_data, content_type, new_ext = compress_zip_streaming(file, filename)
        else:
            compressed_data, content_type, new_ext = compress_generic_streaming(file, filename)
        
        if compressed_data is None:
            return jsonify({'error': 'Faylni kichraytirishda xatolik'}), 500
        
        # Yuklab olish uchun javob qaytarish
        response = Response(compressed_data.getvalue(), mimetype=content_type)
        response.headers.set('Content-Disposition', 'attachment', 
                            filename=f"compressed_{filename}")
        
        # Memoryni tozalash
        gc.collect()
        
        return response
        
    except Exception as e:
        logging.error(f"Stream compressda xatolik: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/batch_upload', methods=['POST'])
def batch_upload():
    """Bir nechta fayllarni streaming orqali qabul qilish"""
    try:
        if 'files' not in request.files:
            return jsonify({'error': 'Fayllar tanlanmagan'}), 400
        
        files = request.files.getlist('files')
        compression_level = request.form.get('compression_level', 'medium')
        
        if len(files) == 0:
            return jsonify({'error': 'Fayllar tanlanmagan'}), 400
        
        results = []
        total_original_size = 0
        total_compressed_size = 0
        
        for file in files:
            if file.filename == '':
                continue
            
            filename = secure_filename(file.filename)
            
            # Fayl hajmini o'lchash
            file.seek(0, 2)
            file_size = file.tell()
            file.seek(0)
            total_original_size += file_size
            
            # Faylni saqlash (demo uchun)
            # Haqiqiy loyihada bu streaming orqali amalga oshiriladi
            file_ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else 'bin'
            
            results.append({
                'filename': filename,
                'size': file_size,
                'status': 'success'
            })
        
        # Demo ma'lumotlari
        total_compressed_size = total_original_size * 0.7  # 30% kichraytirish demo
        total_compression_rate = ((total_original_size - total_compressed_size) / total_original_size * 100)
        
        return jsonify({
            'success': True,
            'files': results,
            'total_original_size': total_original_size,
            'total_compressed_size': total_compressed_size,
            'total_compression_rate': round(total_compression_rate, 2)
        })
        
    except Exception as e:
        logging.error(f"Batch uploadda xatolik: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/cleanup', methods=['POST'])
def cleanup():
    """Vaqtincha fayllarni tozalash"""
    try:
        # Uploads papkasini tozalash
        for filename in os.listdir(app.config['UPLOAD_FOLDER']):
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            except Exception as e:
                logging.error(f"{file_path} ni o'chirishda xatolik: {e}")
        
        # Compressed papkasini tozalash
        for filename in os.listdir(app.config['COMPRESSED_FOLDER']):
            file_path = os.path.join(app.config['COMPRESSED_FOLDER'], filename)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            except Exception as e:
                logging.error(f"{file_path} ni o'chirishda xatolik: {e}")
        
        # Memoryni tozalash
        gc.collect()
        
        return jsonify({'success': True, 'message': 'Barcha vaqtincha fayllar tozalandi'})
        
    except Exception as e:
        logging.error(f"Tozalashda xatolik: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/health')
def health_check():
    """Server holatini tekshirish"""
    return jsonify({
        'status': 'healthy',
        'timestamp': time.time(),
        'max_file_size': 'unlimited',
        'supported_formats': list(app.config['ALLOWED_EXTENSIONS'])
    })

if __name__ == '__main__':
    # Server sozlamalari
    app.run(
        debug=True,
        host='0.0.0.0',
        port=5001,
        threaded=True  # Bir nechta so'rovlarni bir vaqtda qayta ishlash
    )