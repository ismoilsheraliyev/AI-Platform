import PyPDF2
from docx import Document
import os
from googletrans import Translator

class DocumentAnalyzer:
    def __init__(self):
        self.translator = Translator()
    
    def extract_text_pdf(self, filepath):
        """Extract text from PDF"""
        text = ""
        with open(filepath, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page in pdf_reader.pages:
                text += page.extract_text()
        return text
    
    def extract_text_docx(self, filepath):
        """Extract text from DOCX"""
        doc = Document(filepath)
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        return text
    
    def extract_text_txt(self, filepath):
        """Extract text from TXT"""
        with open(filepath, 'r', encoding='utf-8') as file:
            return file.read()
    
    def summarize_text(self, text, max_sentences=5):
        """Simple text summarization"""
        sentences = text.split('. ')
        if len(sentences) <= max_sentences:
            return text
        
        important_sentences = sentences[:max_sentences] + sentences[-2:]
        return '. '.join(important_sentences)
    
    def analyze(self, filepath, analysis_type, progress_callback=None):
        """Main analysis method"""
        try:
            if progress_callback:
                progress_callback(10, "Hujjat yuklanmoqda...")
            
            # Extract text based on file type
            ext = os.path.splitext(filepath)[1].lower()
            
            if ext == '.pdf':
                text = self.extract_text_pdf(filepath)
            elif ext in ['.docx', '.doc']:
                text = self.extract_text_docx(filepath)
            elif ext == '.txt':
                text = self.extract_text_txt(filepath)
            else:
                raise ValueError("Qo'llab-quvvatlanmaydigan fayl formati")
            
            if progress_callback:
                progress_callback(40, "Matn tahlil qilinmoqda...")
            
            result = {
                'original_text': text[:1000] + "..." if len(text) > 1000 else text,
                'total_length': len(text),
                'analysis_type': analysis_type
            }
            
            # Perform requested analysis
            if analysis_type == 'summary':
                summary = self.summarize_text(text)
                result['summary'] = summary
                
            elif analysis_type == 'translation':
                if progress_callback:
                    progress_callback(70, "Tarjima qilinmoqda...")
                
                translations = {}
                for lang in ['en', 'ru', 'uz']:
                    try:
                        translation = self.translator.translate(text[:500], dest=lang)
                        translations[lang] = translation.text
                    except:
                        translations[lang] = "Tarjima xatosi"
                
                result['translations'] = translations
                
            elif analysis_type == 'stats':
                words = text.split()
                sentences = text.split('. ')
                
                result['stats'] = {
                    'word_count': len(words),
                    'sentence_count': len(sentences),
                    'character_count': len(text),
                    'average_word_length': sum(len(word) for word in words) / len(words) if words else 0
                }
            
            if progress_callback:
                progress_callback(100, "Tahlil tugadi!")
            
            return result
            
        except Exception as e:
            raise Exception(f"Hujjat tahlilida xato: {str(e)}")