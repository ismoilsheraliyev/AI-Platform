from gtts import gTTS
import tempfile
import os

class TextToSpeech:
    def __init__(self):
        self.language_map = {
            'uz': 'uz',
            'en': 'en',
            'ru': 'ru',
            'tr': 'tr',
            'ar': 'ar'
        }
    
    def convert(self, text, language='uz'):
        """Convert text to speech"""
        try:
            lang_code = self.language_map.get(language, 'uz')
            
            # Create TTS object
            tts = gTTS(text=text, lang=lang_code, slow=False)
            
            # Save to temporary file
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.mp3')
            tts.save(temp_file.name)
            
            return temp_file.name
            
        except Exception as e:
            raise Exception(f"TTS konvertatsiyasida xato: {str(e)}")