from googletrans import Translator
from collections import Counter
import re

class AITools:
    def __init__(self):
        self.translator = Translator()
    
    def summarize(self, text, max_sentences=3):
        """Summarize text"""
        sentences = text.split('. ')
        if len(sentences) <= max_sentences:
            return {
                'original_length': len(text),
                'summary': text,
                'compression_ratio': 1.0
            }
        
        # Simple extractive summarization (take first and last sentences)
        important_sentences = sentences[:max_sentences]
        summary = '. '.join(important_sentences)
        
        return {
            'original_length': len(text),
            'summary_length': len(summary),
            'summary': summary,
            'compression_ratio': len(summary) / len(text) if len(text) > 0 else 0
        }
    
    def analyze_sentiment(self, text):
        """Simple sentiment analysis"""
        positive_words = ['yaxshi', 'alohida', 'ajoyib', 'mukammal', 'zo\'r', 'a\'lo']
        negative_words = ['yomon', 'noqulay', 'qoniqarsiz', 'past', 'yaroqsiz']
        
        words = text.lower().split()
        positive_count = sum(1 for word in words if word in positive_words)
        negative_count = sum(1 for word in words if word in negative_words)
        
        total = positive_count + negative_count
        if total > 0:
            sentiment_score = (positive_count - negative_count) / total
        else:
            sentiment_score = 0
        
        if sentiment_score > 0.1:
            sentiment = "positive"
        elif sentiment_score < -0.1:
            sentiment = "negative"
        else:
            sentiment = "neutral"
        
        return {
            'sentiment': sentiment,
            'score': sentiment_score,
            'positive_words': positive_count,
            'negative_words': negative_count
        }
    
    def extract_keywords(self, text, num_keywords=10):
        """Extract keywords from text"""
        # Remove punctuation and convert to lowercase
        words = re.findall(r'\b\w+\b', text.lower())
        
        # Remove common stopwords (Uzbek)
        stopwords = {'va', 'ham', 'lekin', 'shuning', 'uchun', 'bu', 'ular', 'bilan'}
        filtered_words = [word for word in words if word not in stopwords and len(word) > 2]
        
        # Count word frequencies
        word_counts = Counter(filtered_words)
        keywords = word_counts.most_common(num_keywords)
        
        return {
            'keywords': [{'word': word, 'count': count} for word, count in keywords],
            'total_words': len(words),
            'unique_words': len(set(words))
        }