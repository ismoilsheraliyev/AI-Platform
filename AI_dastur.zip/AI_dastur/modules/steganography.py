from PIL import Image
import numpy as np
import binascii

class Steganography:
    def __init__(self):
        self.delimiter = "####END####"
    
    def text_to_binary(self, text):
        """Convert text to binary"""
        binary = ''.join(format(ord(char), '08b') for char in text + self.delimiter)
        return binary
    
    def binary_to_text(self, binary):
        """Convert binary to text"""
        chars = [binary[i:i+8] for i in range(0, len(binary), 8)]
        text = ''.join(chr(int(char, 2)) for char in chars)
        
        # Find delimiter and extract actual text
        if self.delimiter in text:
            text = text.split(self.delimiter)[0]
        
        return text
    
    def encode_text(self, image_path, text):
        """Encode text into image"""
        try:
            # Open image
            img = Image.open(image_path)
            img_array = np.array(img)
            
            # Convert text to binary
            binary_text = self.text_to_binary(text)
            
            # Check if image can hold the text
            total_pixels = img_array.shape[0] * img_array.shape[1] * 3
            if len(binary_text) > total_pixels:
                raise ValueError("Matn uchun rasm juda kichik")
            
            # Encode binary into LSB of pixels
            flat_array = img_array.flatten()
            
            for i in range(len(binary_text)):
                # Modify LSB of pixel
                flat_array[i] = (flat_array[i] & 0xFE) | int(binary_text[i])
            
            # Reshape back to image dimensions
            encoded_array = flat_array.reshape(img_array.shape)
            encoded_img = Image.fromarray(encoded_array.astype('uint8'))
            
            # Save to temporary file
            import tempfile
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
            encoded_img.save(temp_file.name, 'PNG')
            
            return temp_file.name
            
        except Exception as e:
            raise Exception(f"Matnni kodlashda xato: {str(e)}")
    
    def decode_text(self, image_path):
        """Decode text from image"""
        try:
            # Open image
            img = Image.open(image_path)
            img_array = np.array(img)
            
            # Extract LSB from pixels
            flat_array = img_array.flatten()
            binary_text = ''
            
            for i in range(len(flat_array)):
                binary_text += str(flat_array[i] & 1)
                
                # Check if we have enough bits for delimiter
                if len(binary_text) % 8 == 0:
                    current_text = self.binary_to_text(binary_text)
                    if self.delimiter in current_text:
                        break
            
            # Convert binary to text
            text = self.binary_to_text(binary_text)
            
            return text
            
        except Exception as e:
            raise Exception(f"Matnni dekodlashda xato: {str(e)}")