import os
import whisper
from googletrans import Translator
from moviepy.editor import VideoFileClip
import tempfile

class VideoToText:
    def __init__(self, model_size='base'):
        self.model = whisper.load_model(model_size)
        self.translator = Translator()
    
    def extract_audio(self, video_path):
        """Extract audio from video"""
        video = VideoFileClip(video_path)
        temp_audio = tempfile.NamedTemporaryFile(delete=False, suffix='.wav')
        video.audio.write_audiofile(temp_audio.name, verbose=False, logger=None)
        video.close()
        return temp_audio.name
    
    def transcribe(self, audio_path):
        """Transcribe audio to text"""
        result = self.model.transcribe(audio_path)
        return result['text']
    
    def translate_text(self, text, target_langs):
        """Translate text to multiple languages"""
        translations = {}
        
        for lang in target_langs:
            try:
                translation = self.translator.translate(text, dest=lang)
                translations[lang] = translation.text
            except:
                translations[lang] = f"Tarjima xatosi: {lang}"
        
        return translations
    
    def process(self, video_path, source_lang, target_langs, progress_callback=None):
        """Main processing method"""
        try:
            if progress_callback:
                progress_callback(10, "Video yuklandi, audio qismi ajratilmoqda...")
            
            # Extract audio
            audio_path = self.extract_audio(video_path)
            
            if progress_callback:
                progress_callback(30, "Audio transkripsiya qilinmoqda...")
            
            # Transcribe audio
            text = self.transcribe(audio_path)
            
            if progress_callback:
                progress_callback(60, "Matn tarjima qilinmoqda...")
            
            # Translate text
            translations = self.translate_text(text, target_langs)
            
            # Cleanup
            os.unlink(audio_path)
            
            if progress_callback:
                progress_callback(100, "Tayyor!")
            
            return {
                'original_text': text,
                'translations': translations,
                'source_language': source_lang,
                'target_languages': target_langs
            }
            
        except Exception as e:
            raise Exception(f"Video qayta ishlashda xato: {str(e)}")