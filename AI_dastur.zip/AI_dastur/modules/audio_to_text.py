import whisper
import speech_recognition as sr
from pydub import AudioSegment
import tempfile
import os

class AudioToText:
    def __init__(self):
        self.whisper_model = whisper.load_model("base")
        self.recognizer = sr.Recognizer()
    
    def convert_to_wav(self, audio_path):
        """Convert audio to WAV format if needed"""
        if audio_path.endswith('.wav'):
            return audio_path
        
        audio = AudioSegment.from_file(audio_path)
        temp_wav = tempfile.NamedTemporaryFile(delete=False, suffix='.wav')
        audio.export(temp_wav.name, format='wav')
        return temp_wav.name
    
    def process_with_whisper(self, audio_path):
        """Process audio using Whisper (high accuracy)"""
        result = self.whisper_model.transcribe(audio_path)
        return result['text']
    
    def process_with_sr(self, audio_path):
        """Process audio using SpeechRecognition"""
        with sr.AudioFile(audio_path) as source:
            audio_data = self.recognizer.record(source)
            text = self.recognizer.recognize_google(audio_data, language='uz-UZ')
            return text
    
    def process(self, audio_path, progress_callback=None):
        """Main processing method"""
        try:
            if progress_callback:
                progress_callback(20, "Audio fayli konvertatsiya qilinmoqda...")
            
            # Convert to WAV if needed
            wav_path = self.convert_to_wav(audio_path)
            
            if progress_callback:
                progress_callback(50, "Matn ajratilmoqda (Whisper bilan)...")
            
            # Try Whisper first (more accurate)
            try:
                text = self.process_with_whisper(wav_path)
            except:
                if progress_callback:
                    progress_callback(50, "Whisper xato berdi, SpeechRecognition ishlatilmoqda...")
                text = self.process_with_sr(wav_path)
            
            # Cleanup temporary file
            if wav_path != audio_path:
                os.unlink(wav_path)
            
            if progress_callback:
                progress_callback(100, "Tayyor!")
            
            return {
                'text': text,
                'confidence': 'high',
                'language': 'auto-detected'
            }
            
        except Exception as e:
            raise Exception(f"Audio qayta ishlashda xato: {str(e)}")