import random
from googletrans import Translator

class UzbekLLM:
    def __init__(self):
        self.translator = Translator()
        
        # Sample knowledge base (in a real app, use actual LLM)
        self.knowledge_base = {
            "salom": ["Salom! Qanday yordam bera olaman?", "Assalomu alaykum! Sizga qanday yordam kerak?"],
            "isming nima": ["Mening ismim AI Assist, men sun'iy intellekt dasturiman.", 
                           "Men AI Assist deb atalgan sun'iy intellektman."],
            "rahmat": ["Arzimaydi! Yana savollaringiz bo'lsa, bemalol so'rang.", 
                      "Sizga yordam bera olganimdan xursandman!"],
            "video": ["Videolarni matnga aylantirish uchun video faylni yuklang.", 
                     "Video transkripsiya qilish uchun yuqoridagi video modulidan foydalaning."],
            "audio": ["Audio fayllarni matnga aylantirish uchun audio faylni yuklang."],
            "tarjima": ["Men 3 tilda (o'zbek, ingliz, rus) tarjima qila olaman."],
            "hujjat": ["PDF, DOCX va TXT fayllarni tahlil qilishim mumkin."]
        }
    
    def generate(self, prompt, max_length=100, progress_callback=None):
        """Generate text based on prompt"""
        try:
            if progress_callback:
                progress_callback(10, "So'rov tahlil qilinmoqda...")
            
            prompt_lower = prompt.lower()
            response = ""
            
            # Check if prompt matches knowledge base
            for key in self.knowledge_base:
                if key in prompt_lower:
                    responses = self.knowledge_base[key]
                    response = random.choice(responses)
                    break
            
            # If no match, create a generic response
            if not response:
                if progress_callback:
                    progress_callback(50, "Javob generatsiya qilinmoqda...")
                
                # Try to translate if prompt is not in Uzbek
                try:
                    translation = self.translator.translate(prompt, dest='uz')
                    uzbek_prompt = translation.text
                    
                    # Generate response based on translated prompt
                    if any(word in uzbek_prompt.lower() for word in ['nima', 'qanday', 'kim']):
                        response = f"{uzbek_prompt} - bu haqida ma'lumotim cheklangan. Boshqa savollaringiz bo'lsa, javob berishga harakat qilaman."
                    else:
                        response = f"{uzbek_prompt} - bu mavzu haqida sizga yordam bera olishim mumkin. Qo'shimcha ma'lumot berishingiz mumkinmi?"
                except:
                    response = "Sizning so'rovingizni tushundim. Bu mavzuda yordam bera olishim uchun biroz ko'proq ma'lumot bering."
            
            # Limit response length
            if len(response) > max_length:
                response = response[:max_length] + "..."
            
            if progress_callback:
                progress_callback(100, "Javob tayyor!")
            
            return response
            
        except Exception as e:
            raise Exception(f"LLM generatsiyasida xato: {str(e)}")